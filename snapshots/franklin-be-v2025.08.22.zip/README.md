# Franklin Builder’s Edition

Franklin is a self-hosted, hybrid AI assistant that combines local file tools, natural language routing, and a privacy-first design. The Builder’s Edition is a slimmed-down public snapshot for developers, homelabbers, and open-source contributors.