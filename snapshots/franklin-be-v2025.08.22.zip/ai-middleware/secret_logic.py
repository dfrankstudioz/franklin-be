def secret_summary(text: str) -> str:
    # Dev stub — this ensures tests detect STUB MODE while container can still boot
    raise NotImplementedError("secret_logic is stubbed in dev mode")

# NOTE: The presence of "NotImplementedError" in this file is enough for tests to detect stub mode.
